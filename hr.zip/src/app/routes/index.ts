import { Router } from "express";
import { UserRoutes } from "../modules/user/user.routes";
import { AuthRoutes } from "../modules/auth/auth.routes";
import { EmployeeRoutes } from "../modules/employee/employee.route";
import { LeaveRoutes } from "../modules/leave/leave.route";
import { AttendanceRoutes } from "../modules/attendence/attendance.route";
import { BonusRoutes } from "../modules/bonus/bonus.route";
import { TaskRoutes } from "../modules/task/task.route";
import { RequisitionRoutes } from "../modules/requisition/requisition.route";
import { HolidayRoutes } from "../modules/holiday/holiday.route";
import { AdvanceSalaryRoutes } from "../modules/advanceSalary/advanceSalary.route";
import { LunchRoutes } from "../modules/lunch/lunch.route";
import { TrainingScheduleRoutes } from "../modules/trainingSchedule/trainingSchedule.route";

export const router = Router();

const modulesRoutes =[
    {
        path: "/user",
        route: UserRoutes
    },
    { path: "/auth", route: AuthRoutes },
     { path: "/attendance", route: AttendanceRoutes },
     { path: "/employees", route: EmployeeRoutes },
     { path: "/leaves", route: LeaveRoutes },
     {path: "/bonus", route: BonusRoutes},
     {path: "/tasks", route: TaskRoutes},
     {
    path: "/requisitions",
    route: RequisitionRoutes,
  },
  { path: "/holidays", route: HolidayRoutes },
  { path: "/advance-salary", route: AdvanceSalaryRoutes },
  { path: "/lunch", route: LunchRoutes },
  { path: "/training-schedules", route: TrainingScheduleRoutes },
]

modulesRoutes.forEach(route => router.use(route.path, route.route));