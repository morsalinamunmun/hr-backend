import { Request, Response } from "express";
import { AttendanceService } from "./attendance.service";

export const AttendanceController = {
  markAttendance: async (req: Request, res: Response) => {
    try {
      const result = await AttendanceService.markAttendance(req.body);
      res.status(result.success ? 200 : 400).json(result);
    } catch (error) {
      console.error(error);
      res.status(500).json({ success: false, message: "Server Error" });
    }
  },

  getUserAttendance: async (req: Request, res: Response) => {
    try {
      const { userId } = req.params;
      const records = await AttendanceService.getUserAttendance(userId);
      res.status(200).json({ success: true, data: records });
    } catch (error) {
      console.error(error);
      res.status(500).json({ success: false, message: "Server Error" });
    }
  },

  getAllAttendance: async (req:Request, res:Response) => {
  try {
    const result = await AttendanceService.getAllAttendance(req.query);

    res.status(200).json({
      success: true,
      data: result.data,
      meta: result.meta,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch attendance",
    });
  }
},

  updateRemarks: async (req: Request, res: Response) => {
    try {
      const result = await AttendanceService.updateRemarks(
        req.params.id,
        req.body?.type,
        req.body?.remarks
      );
      const status = result.success
        ? 200
        : result.message === "Attendance record not found"
        ? 404
        : 400;
      res.status(status).json(result);
    } catch (error) {
      console.error(error);
      res.status(500).json({ success: false, message: "Server Error" });
    }
  },
};
