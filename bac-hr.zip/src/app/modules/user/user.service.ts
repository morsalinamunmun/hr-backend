
import bcryptjs from "bcryptjs"
import httpStatus from "http-status-codes"
import { envVars } from "../../config/env"
import type { IUser, IUserAuth } from "./user.interface"
import { UserStatus, UserVerified,UserRole } from "./user.interface"
import { User } from "./user.model"
import AppError from "../../errorHelpers/AppError"

// const createUser = async (payload: Partial<IUser>) => {
//   const { email, password, role, ...rest } = payload

//   const isUserExist = await User.findOne({ email })
//   if (isUserExist) {
//     throw new AppError(httpStatus.BAD_REQUEST, "User Already Exist")
//   }

//   const hashedPassword = await bcryptjs.hash(password as string, Number(envVars.BCRYPT_SALT_ROUND))

//   const authProvider: IUserAuth = {
//     provider: "credentials",
//     providerId: email as string,
//   }

//   // Fixed: Changed 'auths' to 'auth' to match your schema
//   const user = await User.create({
//     email,
//     password: hashedPassword,
//     auth: [authProvider], // This was 'auths' before, should be 'auth'
//     role: role as UserRole,
//       isActive: UserStatus.ACTIVE,
//   isVerified: UserVerified.PENDING,  // Set default status to PENDING
//     ...rest, // This includes the role from the request
//   })

//   return user
// }

const createUser = async (payload: Partial<IUser>) => {
  const { email, password, role, ...rest } = payload

  const isUserExist = await User.findOne({ email })
  if (isUserExist) {
    throw new AppError(httpStatus.BAD_REQUEST, "User Already Exist")
  }

  // 🔹 Last employee id বের করো
  const lastUser = await User.findOne()
    .sort({ createdAt: -1 })
    .select("employee_id")

  let newEmployeeId = "250060" // default start

  if (lastUser?.employee_id) {
    const lastIdNumber = parseInt(lastUser.employee_id)
    newEmployeeId = String(lastIdNumber + 1)
  }

  const hashedPassword = await bcryptjs.hash(
    password as string,
    Number(envVars.BCRYPT_SALT_ROUND)
  )

  const authProvider: IUserAuth = {
    provider: "credentials",
    providerId: email as string,
  }

  const user = await User.create({
    email,
    password: hashedPassword,
    employee_id: newEmployeeId, // 🔥 auto generated
    auth: [authProvider],
    role: role as UserRole,
    isActive: UserStatus.ACTIVE,
    isVerified: UserVerified.PENDING,
    ...rest,
  })

  return user
}
const verifyUser = async (id: string) => {
  const user = await User.findById(id);
  if (!user) throw new AppError(404, "User not found");

   user.isVerified = UserVerified.APPROVED;
  await user.save();

  return user;
}; 

const getAllUsers = async () => {
  const users = await User.find({}).select("-password") // Exclude password from response
  const totalUsers = await User.countDocuments()
  return {
    data: users,
    meta: {
      total: totalUsers,
    },
  }
}

// get single user
const getUserById = async (id: string) => {
  const user = await User.findById(id).select("-password");
  return user;
};

const blockUser = async (userId: string, requesterRole: UserRole) => {
  const user = await User.findById(userId);

  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found");
  }

  if (  requesterRole === UserRole.ADMIN &&
    user.role === UserRole.SUPER_ADMIN) {
    throw new AppError( httpStatus.FORBIDDEN,
      "Admin cannot block Super Admin");
  }

  user.isActive = UserStatus.BLOCKED; // UserStatus.BLOCKED
  await user.save();

  return user;
};

const unblockUser = async (userId: string) => {
  const user = await User.findById(userId);

  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found");
  }

  user.isActive = UserStatus.ACTIVE; // UserStatus.ACTIVE
  await user.save();

  return user;
};

export const UserServices = {
  createUser,
  verifyUser,
  getAllUsers,
  getUserById,
  blockUser,
  unblockUser
}
